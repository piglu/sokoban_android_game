socoban for palm by marvinizer-zero
finished in 18/feb/2004
----------------------------------------------------------------------------

this is my first skin for sokoban++ for windows

there is all 64 combinations of skin/bg/mode from the game
socoban for the palmOS systems

----------------------------------------------------------------------------
mode/resolution (2)           -   gfxset/skin (4)   -  background (8)
----------------------------------------------------------------------------
1.- hi-res mode(hi)           -   1.- boxy boy      -  1.- black background
2.- normal resolution(nrm)    -   2.- skull & bones -  2.- black with stripes
                                  3.- purple ball   -  3.- white with stripes
                                  4.- aquarium      -  4.- blue slashes
                                                       5.- blue spheres
                                                       6.- dark spheres
                                                       7.- black skulls
                                                       8.- white background
------------------------------------------------------------------------------

socoban is � 1999-2003 Megasoft2000. 