# Sokoban skins

This is a collection of a few free [Sokoban][sk] skins by [Borgar Þorsteinsson][bt]. They were originally drawn for a desktop, and later a [JavaScript, implementation][js] of the game. 

The skins are provided with a [Creative Commons Attribution 3.0][cc] license.

The skins exist in several sizes and flavours. Use them in your Sokoban programs. Credit me. Have fun!

[sk]: http://en.wikipedia.org/wiki/Sokoban
[bt]: http://borgar.net
[js]: https://github.com/borgar/jquery-sokoban
[cc]: http://creativecommons.org/licenses/by/3.0/